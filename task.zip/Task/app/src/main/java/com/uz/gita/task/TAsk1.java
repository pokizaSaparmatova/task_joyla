package com.uz.gita.task;

import java.util.Scanner;

public class TAsk1 {
    public static void main(String[] args) {
        Scanner in=new Scanner(System.in);
        double W,y,r;
        y=in.nextDouble();
        r=in.nextDouble();
        System.out.println(W=Math.exp(y+r)+7.2*Math.sin(r));
    }
}
