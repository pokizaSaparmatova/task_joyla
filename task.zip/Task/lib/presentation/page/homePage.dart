import 'package:easy_debounce/easy_debounce.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:pull_to_refresh/pull_to_refresh.dart';
import 'package:task/di.dart';
import 'package:task/presentation/bloc/home_bloc.dart';

class HomePage extends StatefulWidget {
  const HomePage({Key? key}) : super(key: key);

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  final bloc = di.get<HomeBloc>();
  final controller = RefreshController();

  Widget appBarTitle = const Text(
    "Joyla",
    style:  TextStyle(color: Colors.black),
  );
  Icon actionIcon =  const Icon(
    Icons.search,
    color: Colors.black,
  );
  final key = GlobalKey<ScaffoldState>();
  final TextEditingController _searchQuery =  TextEditingController();
  bool _isSearching = false;

  @override
  void initState() {
    bloc.add(HomeInitEvent());
    _searchQuery.addListener(() {
      EasyDebounce.debounce("debounce", const Duration(seconds: 2), () {
        bloc.add(HomeSearchEvent(_searchQuery.text));
      });
    });

    super.initState();
  }

  @override
  void dispose() {
    print("dispose: Joyla");
    bloc.close();
    controller.dispose();
    _searchQuery.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return BlocProvider.value(
      value: bloc,
      child: BlocListener<HomeBloc, HomeState>(
        listener: (context, state) {
          if (state.status == Status.success) {
            controller.refreshCompleted();
            controller.loadComplete();
          }
        },
        child: BlocBuilder<HomeBloc, HomeState>(
          builder: (context, state) {
            return Scaffold(
              appBar: buildBar(context),
              body: Builder(builder: (context) {
                if (state.status == Status.loading && state.list.isEmpty) {
                  return const Center(child: CircularProgressIndicator());
                }
                else if(state.list.isEmpty){
                  return const Center(child: Text("Empty Data",style: TextStyle(color: Colors.black,fontSize: 40),));
                }
                return SmartRefresher(
                  controller: controller,
                  enablePullDown: true,
                  enablePullUp: true,
                  onRefresh: () {
                    bloc.add(HomeInitEvent());
                  },
                  onLoading: () {
                    bloc.add(HomeNextEvent());
                  },
                  child: ListView.builder(
                    itemCount: state.list.length,
                    itemBuilder: (BuildContext context, int index) {
                      var model = state.list[index];
                      return Card(
                        elevation: 2,
                        child: Container(
                          padding: const EdgeInsets.all(16),
                          child: Row(
                            children: [
                              Column(
                                children: [
                                  ClipRRect(

                                    clipBehavior: Clip.hardEdge,
                                    child: Image.network(
                                      "https://mobile-api.joyla.uz/mobile/${model.imageUrl}",
                                      height: 100,
                                      width: 100,
                                    ),
                                  ),
                                ],
                              ),
                              Expanded(
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text(
                                      "${index + 1}. ${model.name!}",
                                      style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w500),
                                      softWrap: true,
                                      maxLines: 2,
                                    ),
                                    Text(
                                      "Sale price: ${model.price}",
                                      style: TextStyle(fontSize: 16),
                                    ),
                                  ],
                                ),
                              ),
                            ],
                          ),
                        ),
                      );
                    },
                  ),
                );
              }),
            );
          },
        ),
      ),
    );
  }

  AppBar buildBar(BuildContext context) {
    return  AppBar(title: appBarTitle, backgroundColor: Colors.yellow, actions: <Widget>[
      IconButton(
        icon: actionIcon,
        onPressed: () {
          setState(() {
            if (actionIcon.icon == Icons.search) {
              actionIcon =  const Icon(
                Icons.close,
                color: Colors.black,
              );
              appBarTitle =  TextField(
                controller: _searchQuery,
                style: const TextStyle(color: Colors.black, fontSize: 18),
                decoration: const InputDecoration(
                    prefixIcon: Icon(Icons.search, color: Colors.black),
                    hintText: "Search...",
                    border: InputBorder.none,
                    hintStyle: TextStyle(color: Colors.black)),
              );
              _handleSearchStart();
            } else {
              _handleSearchEnd();
            }
          });
        },
      ),
    ]);
  }

  void _handleSearchStart() {
    setState(() {
      _isSearching = true;
    });
  }

  void _handleSearchEnd() {
    setState(() {
      actionIcon =  const Icon(
        Icons.search,
        color: Colors.white,
      );
      appBarTitle = const Text(
        "JOYLA",
        style: TextStyle(color: Colors.white),
      );
      _isSearching = false;
      _searchQuery.clear();
    });
  }
}
