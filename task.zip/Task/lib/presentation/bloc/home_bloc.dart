import 'dart:async';

import 'package:bloc/bloc.dart';
import 'package:meta/meta.dart';
import 'package:task/data/dataSourse/remote_datasource.dart';
import 'package:task/data/model/joyla_model.dart';
import 'package:task/di.dart';

part 'home_event.dart';

part 'home_state.dart';

class HomeBloc extends Bloc<HomeEvent, HomeState> {
  final _homeApi = di.get<HomeApi>();

  HomeBloc() : super(HomeState()) {
    on<HomeInitEvent>((event, emit) async {
      emit(state.copyWith(
        status: Status.loading,
        list: [],
        page: 0,
      ));
      try {
        final product = await _homeApi.getProducts(search: state.search);
        print("current page number :${product.number}");
        print("tottal page  :${product.totalPages}");
        print(" llllllllllllllllllllllll $product");
        emit(state.copyWith(
            status: Status.success,
            list: product.content,
            page: product.number,
            totalPage: product.totalPages));
      } catch (e) {
        print(" llllllllllllllllllllllll $e");
      }
    });
    on<HomeNextEvent>((event, emit) async {
      if (state.page >= state.totalPage) return;

      emit(state.copyWith(status: Status.loading));
      try {
        final list = <Product>[];
        list.addAll(state.list);
        final product = await _homeApi.getProducts(
          search: state.search,
          page: state.page + 1,
        );
        list.addAll(product.content);
        print("current page number :${product.number}");
        print("tottal page  :${product.totalPages}");
        emit(state.copyWith(
          status: Status.success,
          list: list,
          page: product.number,
          totalPage: product.totalPages,
        ));
        print("LISTTTTTTTTTTTTTTTTT: ${list.length}");
      } catch (e) {}
    });
    on<HomeSearchEvent>((event, emit) async {
      emit(state.copyWith(
        status: Status.loading,
        search: event.text,
        page: 0,
        list: [],
      ));
      try {
        final product = await _homeApi.getProducts(search: state.search);
        emit(state.copyWith(
          status: Status.success,
          list: product.content,
          page: product.number,
          totalPage: product.totalPages,
        ));
      } catch (e) {}
    });
  }
}
