import 'package:dio/dio.dart';
import 'package:get_it/get_it.dart';
import 'package:task/data/dataSourse/base_api.dart';
import 'package:task/data/dataSourse/remote_datasource.dart';
import 'package:task/presentation/bloc/home_bloc.dart';

final di = GetIt.instance;

Future<void> setUp() async {

  di.registerSingleton(BaseApi(Dio(BaseOptions(
      baseUrl: "https://mobile-api.joyla.uz/mobile/",
      connectTimeout: const Duration(seconds: 60)))));

  // di.registerSingleton(() => HomeApi(di.get()));

  di.registerFactory(() => HomeApi(di.get()));

  di.registerFactory(() => HomeBloc());

  print("hhhhhhhhhhhhhhhhhhhhhhhhhhhhh");
}
