import 'package:dio/dio.dart';

class BaseApi{
final Dio dio;

  BaseApi(this.dio){}

}